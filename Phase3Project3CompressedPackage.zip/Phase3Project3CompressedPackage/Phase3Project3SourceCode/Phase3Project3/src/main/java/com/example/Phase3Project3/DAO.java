package com.example.Phase3Project3;

public class DAO {
	static int intId;
}

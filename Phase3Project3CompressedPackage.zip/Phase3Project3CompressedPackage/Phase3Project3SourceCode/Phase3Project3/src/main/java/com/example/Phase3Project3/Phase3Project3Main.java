package com.example.Phase3Project3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3Project3Main {
	public static void main(String[] args) {
		SpringApplication.run(Phase3Project3Main.class, args);
	}
}

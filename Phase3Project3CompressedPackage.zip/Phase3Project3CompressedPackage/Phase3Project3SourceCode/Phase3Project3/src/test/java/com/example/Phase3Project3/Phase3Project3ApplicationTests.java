package com.example.Phase3Project3;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Phase3Project3ApplicationTests {

	@Autowired
	UserRepository userRepository;
	
	//The first two tests verify some needed CRUD repository methods
	//Note the save() method is tested later as it is used in a service method
	@Test
	void testCRUD_Count() {
		assertTrue(userRepository.count() > 0);
	}
	
	@Test
	void testCRUD_Delete() {
		User user = new User("TheTestUser", "TheTestUser'sPassword");
		userRepository.save(user);
		long countBefore = userRepository.count();
		userRepository.delete(user);
		assertTrue(userRepository.count() < countBefore);
	}
	
	
	//This is a default test and I disabled it and left it as a reminder of the @Disabled annotation
	@Disabled
	@Test
	void contextLoads() {
	}
	
	//This method utilizes the @AfterEach annoation to ensure the static variable DAO.intId is never modified
	@AfterEach
	void testDAO() {
		System.out.println("Testing DAO.intId");
		assertEquals(0, DAO.intId);
	}

	//The methods in this section test our VerifyService class methods
	@Test
	void testVerifyTest() {
		assertThrows(NumberFormatException.class, () -> Integer.parseInt("12wert09"));
	}
	
	@Test
	void testGetUserValidId() {
		assertNotNull(userRepository.findById(1).get());
	}
	
	@Test
	void testGetUserInvalidId() {
		assertThrows(java.util.NoSuchElementException.class, () -> userRepository.findById(0).get());
	}
	
	@Test
	void testEditUser() {
		User user = new User("TheTestUser", "TheTestUser'sPassword");
		long beforeUpdate = userRepository.count();
		userRepository.save(user);
		assertTrue(userRepository.count() > beforeUpdate);
		userRepository.delete(user);
	}
	
	//The tests in this section test our User class's methods
	@Test
	void testUserGetters() {
		User user = userRepository.findById(1).get();
		User user2 = new User();
		user2.setUsername("basicUser");
		user2.setPassword("basicPassword");
		assertAll(
				() -> assertNotNull(user.getUsername()),
				() -> assertNotNull(user.getPassword()),
				() -> assertNotNull(user.getUserId()),
				
				() -> assertNotNull(user2.getUsername()),
				() -> assertNotNull(user2.getPassword())
				);
	}
	
	@Test
	void testToString() {
		User user = new User();
		assertEquals("User [id=0, username=null, password=null]", user.toString());
	}
}

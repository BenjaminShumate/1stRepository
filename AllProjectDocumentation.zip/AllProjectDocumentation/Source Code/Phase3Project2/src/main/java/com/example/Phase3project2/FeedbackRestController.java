package com.example.Phase3project2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FeedbackRestController {

	@Autowired
	private FeedbackService feedbackService;
	
	 @PostMapping(value="/feedback") 
	 public String showWelcomePage(ModelMap model, @RequestParam String label, @RequestParam String comment){
	 feedbackService.submitComment(label, comment);
	 return "Your label: "+label+" and your comment: "+comment + " Have been submitted to the database";
	 }
	
}

package com.example.Phase3project2;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table
public class Feedback {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String label;
	private String comment;
	
	public Feedback() {
		super();
		}
	
	public Feedback(String label, String comment) {
		super();
		this.label = label;
		this.comment = comment;
	}
	
	public Feedback(int id, String label, String comment) { //Temporary
		super();
		this.id = id;
		this.label = label;
		this.comment = comment;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Feedback [id=" + id + ", label=" + label + ", comment=" + comment + "]";
	}
	
	
	

}

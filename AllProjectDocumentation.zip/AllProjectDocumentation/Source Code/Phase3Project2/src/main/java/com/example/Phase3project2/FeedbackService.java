package com.example.Phase3project2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FeedbackService {
	
	@Autowired
	FeedbackRepository feedbackRepository;
	
	public void submitComment(String label, String comment) {
		
		Feedback feedback = new Feedback(label, comment);	
		feedbackRepository.save(feedback);
	}
	
}

package com.example.Phase3Project1;

public class DAO {
	static int intId;
}

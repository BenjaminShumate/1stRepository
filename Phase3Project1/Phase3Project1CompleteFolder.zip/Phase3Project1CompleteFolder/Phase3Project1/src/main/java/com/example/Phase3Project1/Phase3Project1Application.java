package com.example.Phase3Project1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3Project1Application {
	public static void main(String[] args) {
		SpringApplication.run(Phase3Project1Application.class, args);
	}
}
